-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 26, 2022 at 09:07 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `counselling`
--

-- --------------------------------------------------------

--
-- Table structure for table `addcourse`
--

CREATE TABLE `addcourse` (
  `addc_id` int(11) NOT NULL,
  `agencyid` varchar(255) NOT NULL,
  `goal` varchar(255) NOT NULL,
  `name` varchar(200) NOT NULL,
  `sub` varchar(255) NOT NULL,
  `duration` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `addcourse`
--

INSERT INTO `addcourse` (`addc_id`, `agencyid`, `goal`, `name`, `sub`, `duration`, `amount`) VALUES
(10, '8', 'Banker', 'Bcom', 'Accounting', '3', '25000'),
(11, '8', 'Banker', 'Mcom', 'Accounting', '2', '15000'),
(12, '9', 'Web Developer', 'BCA', 'Computer Applications', '3', '32000'),
(13, '9', 'Web Developer', 'MCA', 'Computer Applications', '2', '28000'),
(14, '12', 'Business Manger', 'BBA', 'Business', '3', '40000'),
(15, '12', 'Business Manger', 'MBA', 'Business', '2', '35000');

-- --------------------------------------------------------

--
-- Table structure for table `agency`
--

CREATE TABLE `agency` (
  `aid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `agency`
--

INSERT INTO `agency` (`aid`, `name`, `email`, `phone`, `pass`) VALUES
(1, 'IOSagency', 'ios@gmail.com', '8899776668', 'ios'),
(6, 'Nosce', 'nosce@gmail.com', '9008456102', 'nosce'),
(8, 'TipsiKani', 'tipsikan@gmail.co', '9876562389', 'tipsiKani'),
(9, 'Simmy', 'simmy@gmail.com', '9061083353', 'Simmy@12'),
(10, 'Marian', 'marian@gmail.com', '8303678829', 'marian12'),
(11, 'Jeeva', 'jeeva@gmail', '9812564398', 'jeeva123'),
(12, 'Tony', 'tony123@gmail.com', '8762394356', 'tony1234');

-- --------------------------------------------------------

--
-- Table structure for table `agencyteractostudent`
--

CREATE TABLE `agencyteractostudent` (
  `as_id` int(11) NOT NULL,
  `agnid` varchar(255) NOT NULL,
  `sname` varchar(255) NOT NULL,
  `des` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `agencyteractostudent`
--

INSERT INTO `agencyteractostudent` (`as_id`, `agnid`, `sname`, `des`) VALUES
(1, '1', 'coun@gmail.com', 'You are eligible to take admission'),
(2, '1', 'coun@gmail.com', ' You Are eligible to Take Admission'),
(3, '2', 'jeni@gmail.com', ' Jeni- We will take your admission what you think'),
(5, '6', 'christo@gmail.com', ' okey'),
(6, '1', 'christo@gmail.com', ' hi maritta'),
(7, '3', 'christo@gmail.com', ' hii shinto'),
(8, '8', 'jeni@gmail.com', ' i varun.. i jeni your agency\r\n'),
(9, '8', 'jeni@gmail.com', ' Hii Prince'),
(10, '8', 'jeni@gmail.com', ' Hii hii prince\r\n'),
(11, '8', 'jeni@gmail.com', ' tikojuoi'),
(12, '8', 'prince@gmail.com', 'to do that you have to take counl...'),
(13, '8', 'prince@gmail.com', '  Agin...Hello Prince we are deciced to do that you have to take counl...');

-- --------------------------------------------------------

--
-- Table structure for table `confirm`
--

CREATE TABLE `confirm` (
  `cnfm_id` int(11) NOT NULL,
  `userid` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `courseid` varchar(255) NOT NULL,
  `des` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `confirm`
--

INSERT INTO `confirm` (`cnfm_id`, `userid`, `username`, `courseid`, `des`) VALUES
(1, '1', 'varun@gmail.com', '1', 'yes i want admission'),
(6, '1', 'varun@gmail.com', '1', 'confirm booking'),
(7, '1', 'varun@gmail.com', '1', 'i take MBA course'),
(9, '1', 'varun@gmail.com', '3', 'i take this course'),
(10, '5', 'maritta@gmail.com', '1', 'i take this course'),
(11, '5', 'maritta@gmail.com', '8', 'confirm'),
(12, '5', 'maritta@gmail.com', '3', 'hh'),
(13, '1', 'varun@gmail.com', '3', 'bb'),
(14, '14', 'arun@gmail.com', '1', 'i booked MBA'),
(15, '1', 'varun@gmail.com', '8', 'i selected Mcom course'),
(16, '17', 'varun@gmail.com', '9', 'i choose Bca course'),
(17, '19', 'prince@gmail.com', '8', 'I am Prince..  I booked Bcom\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `couinteractostudent`
--

CREATE TABLE `couinteractostudent` (
  `cinterid` int(11) NOT NULL,
  `conid` varchar(255) NOT NULL,
  `sname` varchar(255) NOT NULL,
  `des` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `couinteractostudent`
--

INSERT INTO `couinteractostudent` (`cinterid`, `conid`, `sname`, `des`) VALUES
(1, '1', 'varun@gmail.com', 'Candidate You want to take admission'),
(2, '1', 'varun@gmail.com', 'Student you should take a admission'),
(3, '2', 'maria@gmail.com', 'Maria You Shoud Take career admission'),
(4, '2', 'varun@gmail.com', 'good mark'),
(5, '3', 'maria@gmail.com', 'maria, u passed test. you take admission'),
(6, '2', 'maria@gmail.com', 'good'),
(7, '3', 'maritta@gmail.com', 'i maritta.. i am christo'),
(8, '3', 'shinto@gmail.com', 'good mark'),
(9, '2', 'arun@gmail.com', 'hi arun..'),
(10, '2', 'varun@gmail.com', 'i inform Tipsikani Agency'),
(11, '2', 'prince@gmail.com', 'Congratulations Prince for got it good mark. I will assign a agency for your admission process.\r\nI choose TipsiKani Agency. Okey....If you any doubts, Please free feel contact. Thank you Prince.');

-- --------------------------------------------------------

--
-- Table structure for table `counsel`
--

CREATE TABLE `counsel` (
  `cid` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `qual` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `addr` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `counsel`
--

INSERT INTO `counsel` (`cid`, `name`, `qual`, `email`, `addr`, `phone`, `pass`) VALUES
(1, 'coun', 'MCA', 'coun@gmail.com', 'kerala', '7887877776', 'coun'),
(2, 'jeni', 'ME', 'jeni@gmail.com', 'Kadavandthra', '9988776655', 'jeni'),
(3, 'Christo', 'Mcom', 'christo@gmail.com', 'Kottayam', '8790451210', 'christo'),
(4, 'albin', 'mca', 'albin@gmail.com', 'NJARACKAL\r\nTHIDANAD\r\nTHIDANAD', '9087345612', '1qaz2wsx');

-- --------------------------------------------------------

--
-- Table structure for table `counstudent`
--

CREATE TABLE `counstudent` (
  `cid` int(11) NOT NULL,
  `sid` varchar(255) NOT NULL,
  `mark` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `counstudent`
--

INSERT INTO `counstudent` (`cid`, `sid`, `mark`, `name`) VALUES
(1, '1', '30', 'varun@gmail.com'),
(4, '2', '20', 'maria@gmail.com'),
(5, '1', '4', 'varun@gmail.com'),
(6, '5', '8', 'maritta@gmail.com'),
(7, '7', '8', 'shinto@gmail.com'),
(8, '5', '0', 'maritta@gmail.com'),
(9, '5', '3', 'maritta@gmail.com'),
(10, '14', '7', 'arun@gmail.com'),
(11, '1', '6', 'varun@gmail.com'),
(12, '18', '9', 'robin@gmail.com'),
(13, '19', '6', 'prince@gmail.com'),
(14, '19', '2', 'prince@gmail.com'),
(15, '19', '1', 'prince@gmail.com'),
(16, '19', '1', 'prince@gmail.com'),
(17, '19', '1', 'prince@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `logid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `uid` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`logid`, `name`, `pass`, `type`, `status`, `uid`) VALUES
(1, 'varun@gmail.com', 'varun', 'student', '0', '1'),
(2, 'coun@gmail.com', 'coun', 'counsel', '0', '1'),
(3, 'admin@gmail.com', 'admin', 'admin', '1', '0'),
(4, 'ios@gmail.com', 'ios', 'agency', '0', '1'),
(5, 'maria@gmail.com', 'maria', 'student', '0', '2'),
(6, 'jeni@gmail.com', 'jeni12345', 'counsel', '0', '2'),
(8, 'simmy@gmail.com', 'simmy12345', 'agency', '0', '3'),
(13, 'maritta@gmail.com', 'maritta', 'student', '0', '5'),
(14, 'christo@gmail.com', 'christo12345', 'counsel', '0', '3'),
(15, 'nosce@gmail.com', 'nosce12345', 'agency', '0', '6'),
(17, 'shinto@gmail.com', 'shinto12345', 'student', '0', '7'),
(19, 'tipsi@gmail.com', 'tipsi12345', 'agency', '0', '8'),
(31, 'jeeva@gmail.com', 'jeeva12345', 'agency', '0', '11'),
(32, 'tony@gmail.com', 'tony12345', 'agency', '0', '12'),
(36, 'varun@gmail.com', 'varun12345', 'student', '0', '17'),
(37, 'robin@gmail.com', 'robin12345', 'student', '0', '18'),
(38, 'prince@gmail.com', 'prince12345', 'student', '0', '19');

-- --------------------------------------------------------

--
-- Table structure for table `notifyagency`
--

CREATE TABLE `notifyagency` (
  `na_id` int(11) NOT NULL,
  `cid` varchar(255) NOT NULL,
  `csid` varchar(255) NOT NULL,
  `agency` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `des` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notifyagency`
--

INSERT INTO `notifyagency` (`na_id`, `cid`, `csid`, `agency`, `name`, `des`) VALUES
(1, '1', '1', 'IOSagency', 'coun@gmail.com', 'The Student have 30 mark'),
(3, '2', '5', 'Simmy', 'jeni@gmail.com', 'he want more communicate...'),
(4, '2', '1', 'IOSagency', 'jeni@gmail.com', 'please take varun'),
(5, '3', '4', 'Nosce', 'christo@gmail.com', 'take maria'),
(6, '2', '4', 'IOSagency', 'jeni@gmail.com', 'take ios agency'),
(7, '3', '6', 'IOSagency', 'christo@gmail.com', 'u take'),
(8, '3', '7', 'Simmy', 'christo@gmail.com', 'shint6o want a admission..'),
(9, '2', '10', 'Tony', 'jeni@gmail.com', 'please take arun'),
(10, '2', '11', 'TipsiKani', 'jeni@gmail.com', 'varun got 6 mark'),
(11, '2', '11', 'Simmy', 'jeni@gmail.com', 'Hii, take varun'),
(12, '2', '12', 'Simmy', 'jeni@gmail.com', 'u take simmy agency'),
(13, '2', '13', 'TipsiKani', 'jeni@gmail.com', 'I give Prince student  for admission process.');

-- --------------------------------------------------------

--
-- Table structure for table `stalktoagency`
--

CREATE TABLE `stalktoagency` (
  `talk_id` int(11) NOT NULL,
  `stu_id` varchar(255) NOT NULL,
  `agency` varchar(255) NOT NULL,
  `sname` varchar(255) NOT NULL,
  `des` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stalktoagency`
--

INSERT INTO `stalktoagency` (`talk_id`, `stu_id`, `agency`, `sname`, `des`) VALUES
(1, '1', 'IOSagency', 'varun@gmail.com', 'Thank You For Provide Career chance'),
(4, '1', 'IOSagency', 'varun@gmail.com', 'thank you for the admission..'),
(5, '1', 'IOSagency', 'varun@gmail.com', 'i select MBA course'),
(6, '1', 'Simmy', 'varun@gmail.com', 'Thank you for the admission\r\n'),
(7, '5', 'Nosce', 'maritta@gmail.com', 'i want admissin'),
(8, '5', 'Nosce', 'maritta@gmail.com', 'i passed test.. i want a admission'),
(9, '1', 'Simmy', 'varun@gmail.com', 'i am varun'),
(10, '5', 'Simmy', 'maritta@gmail.com', 'admission ?'),
(11, '1', 'TipsiKani', 'varun@gmail.com', 'hi i am varun...i have 6 mark..so i booked MCom'),
(12, '17', 'Simmy', 'varun@gmail.com', 'hii i am varun'),
(13, '19', 'TipsiKani', 'prince@gmail.com', 'Hii.. I am Prince'),
(14, '19', 'TipsiKani', 'prince@gmail.com', 'hi  i am prince');

-- --------------------------------------------------------

--
-- Table structure for table `studentreg`
--

CREATE TABLE `studentreg` (
  `sid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `addr` varchar(255) NOT NULL,
  `qual` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentreg`
--

INSERT INTO `studentreg` (`sid`, `name`, `email`, `phone`, `addr`, `qual`, `pass`) VALUES
(2, 'maria', 'maria@gmail.com', '8877666756', 'Ernakulam', 'MCA', 'maria123'),
(5, 'Maritta', 'maritta@gmail.com', '9087347690', 'star house', 'MBA', 'maritta123'),
(7, 'Shinto', 'shinto@gmail.com', '6238058529', 'Alackaprambil house ', 'MCA', 'shinto123'),
(10, 'Jeena', 'Jeena@gmail.com', '9823156098', 'Kolancheril house, Kottayam', 'MCOM', 'Jeena123'),
(14, 'arun', 'arun@gmail.com', '9087345678', 'star house, kottayam', 'plus two', '12345678'),
(17, 'varun', 'varun@gmail.com', '9823459876', 'qwert house, pqrst, xyz', 'plus two', 'varun12345'),
(18, 'Robin', 'robin@gmail.com', '9765475643', 'qwer, pasdf', 'Plus Two', 'robin12345'),
(19, 'prince', 'prince@gmail.com', '9583018022', 'moon house, star village, malgidi', 'Plus Two', 'prince12345');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addcourse`
--
ALTER TABLE `addcourse`
  ADD PRIMARY KEY (`addc_id`);

--
-- Indexes for table `agency`
--
ALTER TABLE `agency`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `agencyteractostudent`
--
ALTER TABLE `agencyteractostudent`
  ADD PRIMARY KEY (`as_id`);

--
-- Indexes for table `confirm`
--
ALTER TABLE `confirm`
  ADD PRIMARY KEY (`cnfm_id`);

--
-- Indexes for table `couinteractostudent`
--
ALTER TABLE `couinteractostudent`
  ADD PRIMARY KEY (`cinterid`);

--
-- Indexes for table `counsel`
--
ALTER TABLE `counsel`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `counstudent`
--
ALTER TABLE `counstudent`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`logid`);

--
-- Indexes for table `notifyagency`
--
ALTER TABLE `notifyagency`
  ADD PRIMARY KEY (`na_id`);

--
-- Indexes for table `stalktoagency`
--
ALTER TABLE `stalktoagency`
  ADD PRIMARY KEY (`talk_id`);

--
-- Indexes for table `studentreg`
--
ALTER TABLE `studentreg`
  ADD PRIMARY KEY (`sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addcourse`
--
ALTER TABLE `addcourse`
  MODIFY `addc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `agency`
--
ALTER TABLE `agency`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `agencyteractostudent`
--
ALTER TABLE `agencyteractostudent`
  MODIFY `as_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `confirm`
--
ALTER TABLE `confirm`
  MODIFY `cnfm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `couinteractostudent`
--
ALTER TABLE `couinteractostudent`
  MODIFY `cinterid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `counsel`
--
ALTER TABLE `counsel`
  MODIFY `cid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `counstudent`
--
ALTER TABLE `counstudent`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `logid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `notifyagency`
--
ALTER TABLE `notifyagency`
  MODIFY `na_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `stalktoagency`
--
ALTER TABLE `stalktoagency`
  MODIFY `talk_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `studentreg`
--
ALTER TABLE `studentreg`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
