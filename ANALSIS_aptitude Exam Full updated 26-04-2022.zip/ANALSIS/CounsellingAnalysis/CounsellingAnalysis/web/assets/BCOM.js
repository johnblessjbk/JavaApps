/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/** 
 * Criteria 
 */

// GIVEN I am taking a code quiz
// WHEN I click the start button
// THEN a timer starts and I am presented with a question
// WHEN I answer a question
// THEN I am presented with another question
// WHEN I answer a question incorrectly
// THEN time is subtracted from the clock
// WHEN all questions are answered or the timer reaches 0
// THEN the game is over
// WHEN the game is over
// THEN I can save my initials and score

/** 
 * DEFINE VARIABLES 
 */

 // Define a set of questions
const questions = [
    {
        question: "Break even, means:",
        choices: ["a. Costs are more than revenue", "b. Revenues and cost are equal", "c. Revenues are more than cost", "d. None of the above"],
        answer: "b. Revenues and cost are equal"
    },
    {
        question: "Which of the following is a current liability?",
        choices: ["a. Debenture", "b. Long term loan", "c. Bank overdraft", "d. Share premium"],
        answer: "c. Bank overdraft"
    },
    {
        question: "‘Garner Vs Murray’ relates to:",
        choices: ["a. Deficiency A/c", "b. Insolvency", "c. Contract", "d. Hire purchase"],
        answer: "b. Insolvency"
    },
    {
        question: "Intangible assets usually fall in the category of:",
        choices: ["a. Current assets", "b. Fixed assets", "c. Semi fixed assets", "d. None of the above"],
        answer: "b. Fixed assets"
    },
    {
        question: "Which one of the following is shown first when the assets are arranged in the order of their liquidity?",
        choices: ["a. Cash in hand", "b. Debtors", "c. Investment", "d. B/R"],
        answer: "a. Cash in hand"
    },
    {
        question: "The balance-sheet is only:",
        choices: ["a. An account", "b. A summary", "c.  A statement", "d.  None of the above"],
        answer: "c.  A statement"
    },
    {
        question: "Teeming and lading relates to:",
        choices: ["a. Pilferage of stock", "b. Misappropriation of cash", "c. Frauds relating to the receipt of money from debtors", "d. Bribery of cash for some benefits"],
        answer: "c. Frauds relating to the receipt of money from debtors"
    },
    {
        question: "Acid test ratio is:",
        choices: ["a. Current assets: current liabilities", "b. Quick assets: current liabilities", "c. Total assets: total liabilities", "d. Fixed assets: fixed liabilities"],
        answer: "b. Quick assets: current liabilities"
    },
    {
        question: "If earning price (EP) ratio is 0.05 and Earnings per share is Rs. 8, the market price of share = :",
        choices: ["a. Rs. 40", "b. Rs. 100", "c. Rs. 160", "d. Rs. 0.40"],
        answer: "c. Rs. 160"
    },
    {
        question: "Liberalization means",
        choices: ["a. Free determination of interest rates", "b. Liberating the industry, trade and economy from unwanted restrictions", "c. Opening up of economy to the world by attaining international competitiveness", "d. Reducing number of reserved industries from 17 to 8"],
        answer: "b. Liberating the industry, trade and economy from unwanted restrictions"
    },
    {
        question: "Which one is not the main objective of Fiscal Policy in India?",
        choices: ["a. To promote employment opportunities", "b. To minimize the inequalities of income and wealth", "c. To promote price stability", "d. To increase liquidity in economy"],
        answer: "d. To increase liquidity in economy"
    },
    {
        question: "Laissez Faire policy is adopted in",
        choices: ["a. Socialist Economic system", "b. Capitalist Economic system", "c.  Communist Economic System", "d.  Mixed Economic System"],
        answer: "b.  Capitalist Economic system"
    },
    {
        question: "Span of management refers to:",
        choices: ["a. Activities performed by a manager", "b. Number of subordinates supervised by a manager", "c.  Number of superiors a manager has to report to", "d. None of the above"],
        answer: "b. Number of subordinates supervised by a manager"
    },
    {
        question: "Who introduced the concept of MBO?",
        choices: ["a. Mary Parker Follet", "b. Keith Device", "c. Peter Drucker", "d. None of the above"],
        answer: "c. Peter Drucker"
    },
    {
        question: "MBO refers to:",
        choices: ["a.  Management by objectives", "b. A technique of achieving organisational goals", "c. Performance review", "d. None of the above"],
        answer: "a.  Management by objectives"
    }
];

// grab references to elements
var timer = document.getElementById("timer");
var timeLeft = document.getElementById("timeLeft");
var timesUp = document.getElementById("timesUp");

var startDiv = document.getElementById("start");
var startQuizBtn = document.getElementById("start-quiz-button");

var questionDiv = document.getElementById("questionDiv");
var questionTitle = document.getElementById("questionTitle");
var choiceA = document.getElementById("btn0");
var choiceB = document.getElementById("btn1");
var choiceC = document.getElementById("btn2");
var choiceD = document.getElementById("btn3");
var answerCheck = document.getElementById("answerCheck");

var summary = document.getElementById("summary");
var submitInitialBtn = document.getElementById("submitInitialBtn");
var initialInput = document.getElementById("initialInput");
var everything = document.getElementById("everything");

var highScoreSection = document.getElementById("highScoreSection");
var finalScore = document.getElementById("finalScore");

var goBackBtn = document.getElementById("goBackBtn");
var clearHighScoreBtn = document.getElementById("clearHighScoreBtn"); 
var viewHighScore = document.getElementById("viewHighScore");
var listOfHighScores = document.getElementById("listOfHighScores");

// define other variables
var correctAns = 0;
var questionNum = 0;
var scoreResult;
var questionIndex = 0;

/**
 * FUNCTIONS
 */

// WHEN I click the start button, timer starts
var totalTime = 151;
function newQuiz() {
    questionIndex = 0;
    totalTime = 150;
    timeLeft.textContent = totalTime;
    initialInput.textContent = "";

    startDiv.style.display = "none";
    questionDiv.style.display = "block";
    timer.style.display = "block";
    timesUp.style.display = "none";

    var startTimer = setInterval(function() {
        totalTime--;
        timeLeft.textContent = totalTime;
        if(totalTime <= 0) {
            clearInterval(startTimer);
            if (questionIndex < questions.length - 1) {
                gameOver();
            }
        }
    },1000);

    showQuiz();
};

// console.log(questions[questionIndex].question);
// console.log(questions[questionIndex].choices);

// then presented with questions and choices
function showQuiz() {
    nextQuestion();
}

function nextQuestion() {
    questionTitle.textContent = questions[questionIndex].question;
    choiceA.textContent = questions[questionIndex].choices[0];
    choiceB.textContent = questions[questionIndex].choices[1];
    choiceC.textContent = questions[questionIndex].choices[2];
    choiceD.textContent = questions[questionIndex].choices[3];
}

// after question is answered, show if correct or wrong
function checkAnswer(answer) {

    var lineBreak = document.getElementById("lineBreak");
    lineBreak.style.display = "block";
    answerCheck.style.display = "block";

    if (questions[questionIndex].answer === questions[questionIndex].choices[answer]) {
        // correct answer, add 1 score to final score
        correctAns++;
        // console.log(correctAns);
        answerCheck.textContent = "Correct!";
    } else {
        // wrong answer, deduct 10 second from timer
        totalTime -= 10;
        timeLeft.textContent = totalTime;
        answerCheck.textContent = "Wrong! The correct answer is: " + questions[questionIndex].answer;
    }

    questionIndex++;
    // repeat with the rest of questions 
    if (questionIndex < questions.length) {
        nextQuestion();
    } else {
        // if no more question, run game over function
        gameOver();
    }
}

function chooseA() { checkAnswer(0); }

function chooseB() { checkAnswer(1); }

function chooseC() { checkAnswer(2); }

function chooseD() { checkAnswer(3); }

// when all questions are answered or timer reaches 0, game over
function gameOver() {
    summary.style.display = "block";
    questionDiv.style.display = "none";
    startDiv.style.display = "none";
    timer.style.display = "none";
    timesUp.style.display = "block";

    // show final score
    finalScore.textContent = correctAns;
}

// enter initial and store highscore in local storage
function storeHighScores(event) {
    event.preventDefault();

    // stop function is initial is blank
    if (initialInput.value === "") {
        alert("Please enter your initials!");
        return;
    } 

    startDiv.style.display = "none";
    timer.style.display = "none";
    timesUp.style.display = "none";
    summary.style.display = "none";
    highScoreSection.style.display = "block";   

    // store scores into local storage
    var savedHighScores = localStorage.getItem("high scores");
    var scoresArray;

    if (savedHighScores === null) {
        scoresArray = [];
    } else {
        scoresArray = JSON.parse(savedHighScores)
    }

    var userScore = {
        initials: initialInput.value,
        score: finalScore.textContent
    };

    console.log(userScore);
    scoresArray.push(userScore);

    // stringify array in order to store in local
    var scoresArrayString = JSON.stringify(scoresArray);
    window.localStorage.setItem("high scores", scoresArrayString);
    
    // show current highscores
    showHighScores();
}

// function to show high scores
var i = 0;
function showHighScores() {

    startDiv.style.display = "none";
    timer.style.display = "none";
    questionDiv.style.display = "none";
    timesUp.style.display = "none";
    summary.style.display = "none";
    highScoreSection.style.display = "block";

    var savedHighScores = localStorage.getItem("high scores");

    // check if there is any in local storage
    if (savedHighScores === null) {
        return;
    }
    console.log(savedHighScores);

    var storedHighScores = JSON.parse(savedHighScores);

    for (; i < storedHighScores.length; i++) {
        var eachNewHighScore = document.createElement("p");
        eachNewHighScore.innerHTML = storedHighScores[i].initials + ": " + storedHighScores[i].score;
        listOfHighScores.appendChild(eachNewHighScore);
    }
}

/**
 * ADD EVENT LISTENERS
 */

startQuizBtn.addEventListener("click", newQuiz);
choiceA.addEventListener("click", chooseA);
choiceB.addEventListener("click", chooseB);
choiceC.addEventListener("click", chooseC);
choiceD.addEventListener("click", chooseD);

submitInitialBtn.addEventListener("click", function(event){ 
    storeHighScores(event);
});

viewHighScore.addEventListener("click", function(event) { 
    showHighScores(event);
});

goBackBtn.addEventListener("click", function() {
    startDiv.style.display = "block";
    highScoreSection.style.display = "none";
});

clearHighScoreBtn.addEventListener("click", function(){
    window.localStorage.removeItem("high scores");
    listOfHighScores.innerHTML = "High Scores Cleared!";
    listOfHighScores.setAttribute("style", "font-family: 'Archivo', sans-serif; font-style: italic;")
});