-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 09, 2022 at 03:20 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `counselling`
--

-- --------------------------------------------------------

--
-- Table structure for table `addcourse`
--

CREATE TABLE `addcourse` (
  `addc_id` int(11) NOT NULL,
  `agencyid` varchar(255) NOT NULL,
  `goal` varchar(255) NOT NULL,
  `name` varchar(200) NOT NULL,
  `sub` varchar(255) NOT NULL,
  `duration` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `addcourse`
--

INSERT INTO `addcourse` (`addc_id`, `agencyid`, `goal`, `name`, `sub`, `duration`, `amount`) VALUES
(1, '1', 'Painter', 'Communicate', 'Interaction', '2', '900'),
(2, '2', 'Advocate', 'Communicate', 'interact', '07', '2000'),
(3, '2', 'Lawer', 'Guide', 'Speach', '02', '3000');

-- --------------------------------------------------------

--
-- Table structure for table `agency`
--

CREATE TABLE `agency` (
  `aid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `agency`
--

INSERT INTO `agency` (`aid`, `name`, `email`, `phone`, `pass`) VALUES
(1, 'IOSagency', 'ios@gmail.com', '88997766688', 'ios'),
(2, 'jas', 'jas@gmail.com', '76665665644', 'jas');

-- --------------------------------------------------------

--
-- Table structure for table `agencyteractostudent`
--

CREATE TABLE `agencyteractostudent` (
  `as_id` int(11) NOT NULL,
  `agnid` varchar(255) NOT NULL,
  `sname` varchar(255) NOT NULL,
  `des` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `agencyteractostudent`
--

INSERT INTO `agencyteractostudent` (`as_id`, `agnid`, `sname`, `des`) VALUES
(1, '1', 'coun@gmail.com', 'You are eligible to take admission'),
(2, '1', 'coun@gmail.com', ' You Are eligible to Take Admission'),
(3, '2', 'jeni@gmail.com', ' Jeni- We will take your admission what you think');

-- --------------------------------------------------------

--
-- Table structure for table `confirm`
--

CREATE TABLE `confirm` (
  `cnfm_id` int(11) NOT NULL,
  `userid` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `courseid` varchar(255) NOT NULL,
  `des` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `confirm`
--

INSERT INTO `confirm` (`cnfm_id`, `userid`, `username`, `courseid`, `des`) VALUES
(1, '1', 'varun@gmail.com', '1', 'yes i want admission'),
(2, '2', 'maria@gmail.com', '2', 'Yes i select lawer');

-- --------------------------------------------------------

--
-- Table structure for table `couinteractostudent`
--

CREATE TABLE `couinteractostudent` (
  `cinterid` int(11) NOT NULL,
  `conid` varchar(255) NOT NULL,
  `sname` varchar(255) NOT NULL,
  `des` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `couinteractostudent`
--

INSERT INTO `couinteractostudent` (`cinterid`, `conid`, `sname`, `des`) VALUES
(1, '1', 'varun@gmail.com', 'Candidate You want to take admission'),
(2, '1', 'varun@gmail.com', 'Student you should take a admission'),
(3, '2', 'maria@gmail.com', 'Maria You Shoud Take career admission');

-- --------------------------------------------------------

--
-- Table structure for table `counsel`
--

CREATE TABLE `counsel` (
  `cid` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `qual` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `addr` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `counsel`
--

INSERT INTO `counsel` (`cid`, `name`, `qual`, `email`, `addr`, `phone`, `pass`) VALUES
(1, 'coun', 'MCA', 'coun@gmail.com', 'kerala', '7887877776', 'coun'),
(2, 'jeni', 'ME', 'jeni@gmail.com', 'Kadavandthra', '9988776655', 'jeni');

-- --------------------------------------------------------

--
-- Table structure for table `counstudent`
--

CREATE TABLE `counstudent` (
  `cid` int(11) NOT NULL,
  `sid` varchar(255) NOT NULL,
  `mark` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `counstudent`
--

INSERT INTO `counstudent` (`cid`, `sid`, `mark`, `name`) VALUES
(1, '1', '30', 'varun@gmail.com'),
(2, '1', '1', 'varun@gmail.com'),
(3, '1', '344', 'varun@gmail.com'),
(4, '2', '20', 'maria@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `logid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `uid` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`logid`, `name`, `pass`, `type`, `status`, `uid`) VALUES
(1, 'varun@gmail.com', 'varun', 'student', '0', '1'),
(2, 'coun@gmail.com', 'coun', 'counsel', '0', '1'),
(3, 'admin@gmail.com', 'admin', 'admin', '1', '0'),
(4, 'ios@gmail.com', 'ios', 'agency', '0', '1'),
(5, 'maria@gmail.com', 'maria', 'student', '0', '2'),
(6, 'jeni@gmail.com', 'jeni', 'counsel', '0', '2'),
(7, 'jas@gmail.com', 'jas', 'agency', '0', '2');

-- --------------------------------------------------------

--
-- Table structure for table `notifyagency`
--

CREATE TABLE `notifyagency` (
  `na_id` int(11) NOT NULL,
  `cid` varchar(255) NOT NULL,
  `csid` varchar(255) NOT NULL,
  `agency` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `des` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notifyagency`
--

INSERT INTO `notifyagency` (`na_id`, `cid`, `csid`, `agency`, `name`, `des`) VALUES
(1, '1', '1', 'IOSagency', 'coun@gmail.com', 'The Student have 30 mark'),
(2, '2', '4', 'jas', 'jeni@gmail.com', 'Jas Agency Please Make sure -maria');

-- --------------------------------------------------------

--
-- Table structure for table `stalktoagency`
--

CREATE TABLE `stalktoagency` (
  `talk_id` int(11) NOT NULL,
  `stu_id` varchar(255) NOT NULL,
  `agency` varchar(255) NOT NULL,
  `sname` varchar(255) NOT NULL,
  `des` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stalktoagency`
--

INSERT INTO `stalktoagency` (`talk_id`, `stu_id`, `agency`, `sname`, `des`) VALUES
(1, '1', 'IOSagency', 'varun@gmail.com', 'Thank You For Provide Career chance'),
(2, '2', 'jas', 'maria@gmail.com', 'Yes thank your for guiding');

-- --------------------------------------------------------

--
-- Table structure for table `studentreg`
--

CREATE TABLE `studentreg` (
  `sid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `addr` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentreg`
--

INSERT INTO `studentreg` (`sid`, `name`, `email`, `phone`, `addr`, `pass`) VALUES
(1, 'varun', 'varun@gmail.com', '78767676677', 'Kerala', 'varun'),
(2, 'maria', 'maria@gmail.com', '8877666756', 'Ernakulam', 'maria');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addcourse`
--
ALTER TABLE `addcourse`
  ADD PRIMARY KEY (`addc_id`);

--
-- Indexes for table `agency`
--
ALTER TABLE `agency`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `agencyteractostudent`
--
ALTER TABLE `agencyteractostudent`
  ADD PRIMARY KEY (`as_id`);

--
-- Indexes for table `confirm`
--
ALTER TABLE `confirm`
  ADD PRIMARY KEY (`cnfm_id`);

--
-- Indexes for table `couinteractostudent`
--
ALTER TABLE `couinteractostudent`
  ADD PRIMARY KEY (`cinterid`);

--
-- Indexes for table `counsel`
--
ALTER TABLE `counsel`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `counstudent`
--
ALTER TABLE `counstudent`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`logid`);

--
-- Indexes for table `notifyagency`
--
ALTER TABLE `notifyagency`
  ADD PRIMARY KEY (`na_id`);

--
-- Indexes for table `stalktoagency`
--
ALTER TABLE `stalktoagency`
  ADD PRIMARY KEY (`talk_id`);

--
-- Indexes for table `studentreg`
--
ALTER TABLE `studentreg`
  ADD PRIMARY KEY (`sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addcourse`
--
ALTER TABLE `addcourse`
  MODIFY `addc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `agency`
--
ALTER TABLE `agency`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `agencyteractostudent`
--
ALTER TABLE `agencyteractostudent`
  MODIFY `as_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `confirm`
--
ALTER TABLE `confirm`
  MODIFY `cnfm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `couinteractostudent`
--
ALTER TABLE `couinteractostudent`
  MODIFY `cinterid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `counsel`
--
ALTER TABLE `counsel`
  MODIFY `cid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `counstudent`
--
ALTER TABLE `counstudent`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `logid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `notifyagency`
--
ALTER TABLE `notifyagency`
  MODIFY `na_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `stalktoagency`
--
ALTER TABLE `stalktoagency`
  MODIFY `talk_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `studentreg`
--
ALTER TABLE `studentreg`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
