/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Connection;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author DELL
 */
public class Examsec extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String na = "", ma = "", to = "", g = "", h = "", k = "";
        String idv=request.getParameter("id");
        HttpSession session=request.getSession();  

        String staff=(String)session.getAttribute("loguid");
        String myva=(String)session.getAttribute("myval");

        String q[] = request.getParameterValues("ques");
        String f[] = request.getParameterValues("f");
        String s[] = request.getParameterValues("s");
        String t[] = request.getParameterValues("t");
        String ff[] = request.getParameterValues("ff");
        String ans[] = request.getParameterValues("ans");
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection con = DriverManager.getConnection("jdbc:mysql://Localhost:3306/onlinelearn", "root", "");
            Statement st = con.createStatement();
            for (int i = 0; i < q.length; i++) {
                na = q[i];
                ma = f[i];
                to = s[i];
                g = t[i];
                h = ff[i];
                k = ans[i];
                int is = st.executeUpdate("insert into sch_exam(que,f,s,t,ff,ans,stuid,staffid)values('" + na + "','" + ma + "','" + to + "','" + g + "','" + h + "','" + k + "','"+myva+"','"+staff+"')");
                if (is > 0) {
//                    out.print("sucess");
                    out.println("<script>alert('sucessfull');window.location='../ONLINELearning/Staff/ViewStudent.jsp';</script>");

                } else {
                    out.print("failed");
                }
            }
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | SQLException e) {
            out.print(e);

            //response.sendRedirect("Staff/ViewStudent.jsp");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
