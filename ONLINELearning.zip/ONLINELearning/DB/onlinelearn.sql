-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 09, 2022 at 03:22 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlinelearn`
--

-- --------------------------------------------------------

--
-- Table structure for table `assignment`
--

CREATE TABLE `assignment` (
  `agnid` int(11) NOT NULL,
  `stuid` varchar(200) NOT NULL,
  `staffid` varchar(200) NOT NULL,
  `name` varchar(255) NOT NULL,
  `topic` varchar(200) NOT NULL,
  `dates` varchar(255) NOT NULL,
  `mark` varchar(255) NOT NULL,
  `action` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `assignment`
--

INSERT INTO `assignment` (`agnid`, `stuid`, `staffid`, `name`, `topic`, `dates`, `mark`, `action`) VALUES
(1, '', '', 'Maths', 'Matrix multiplication', '2022-03-12', '200', '0'),
(2, '2', 'null', 'Biology', 'M', '2022-03-03', '200', '1'),
(3, '2', '10', 'HTML', 'Matrix multiplication', '2022-03-22', '400', '1'),
(4, '2', '10', 'jbkbj', 'jhgghhg', '2022-03-11', '33', '1'),
(5, '1', '10', 'Maths', 'M', '2022-03-16', '200', '0'),
(6, '2', '10', 'nvv', 'x xzc', '2022-04-07', '43', '1'),
(7, 'null', '12', 'Zology', 'Plant Growth', '2022-03-19', '780', '0'),
(8, 'null', '12', 'jstaff', 'P', '2022-04-02', '780', '0'),
(9, 'null', '12', 'Maths Matrix', 'm', '2022-03-12', '200', '0'),
(10, 'null', '12', 'Maths Matrix', 'm', '2022-03-11', '200', '0'),
(11, '3', '12', 'Maths Matrix', 'm', '2022-03-11', '200', '0'),
(12, '3', '12', 'Zology', 'Plant Growth', '2022-03-19', '780', '1');

-- --------------------------------------------------------

--
-- Table structure for table `entermark`
--

CREATE TABLE `entermark` (
  `emid` int(11) NOT NULL,
  `sid` varchar(255) NOT NULL,
  `staffname` varchar(255) NOT NULL,
  `per` varchar(255) NOT NULL,
  `mark` varchar(255) NOT NULL,
  `dates` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `entermark`
--

INSERT INTO `entermark` (`emid`, `sid`, `staffname`, `per`, `mark`, `dates`) VALUES
(1, '2', 'mystaff@gmail.com', 'Good', '100', '2022-03-26'),
(2, 'null', 'jstaff@gmail.com', 'Excellent', '80', '2022-03-31'),
(3, 'null', 'jstaff@gmail.com', 'Goodss', '111', '2022-03-29'),
(4, '3', 'jstaff@gmail.com', 'Excellent', '111', '2022-03-17');

-- --------------------------------------------------------

--
-- Table structure for table `exam`
--

CREATE TABLE `exam` (
  `exid` varchar(200) NOT NULL,
  `sname` varchar(255) NOT NULL,
  `fromdate` varchar(255) NOT NULL,
  `todate` varchar(255) NOT NULL,
  `ans` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `extype` varchar(255) NOT NULL,
  `ques` varchar(200) NOT NULL,
  `A` varchar(200) NOT NULL,
  `B` varchar(200) NOT NULL,
  `C` varchar(200) NOT NULL,
  `D` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `exam`
--

INSERT INTO `exam` (`exid`, `sname`, `fromdate`, `todate`, `ans`, `subject`, `extype`, `ques`, `A`, `B`, `C`, `D`) VALUES
('', 'jenis', '2022-03-11 1', '2022-03-18 1', 'A 1', 'Resource Pyramid 1', 'Development 1', 'op 1', 'io 1', 'err 1', 'tttt 1', 'uii 1'),
('', 'jenis', '2022-03-11 1', '2022-03-18 1', 'A 1', 'Resource Pyramid 1', 'Development 1', 'hello 1', 'data 1', 'gh 1', 'lop 1', 'op 1'),
('', 'data', '2022-03-24 1', '2022-03-30 1', 'A 1', 'Resource Pyramid 1', 'Development 1', 'amma 1', 'vv 1', 'jjj 1', 'op 1', 'iooo 1');

-- --------------------------------------------------------

--
-- Table structure for table `examresult`
--

CREATE TABLE `examresult` (
  `erid` int(11) NOT NULL,
  `sid` varchar(255) NOT NULL,
  `fid` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mark` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `examresult`
--

INSERT INTO `examresult` (`erid`, `sid`, `fid`, `name`, `mark`) VALUES
(1, '10', 'null', 'Good', '200'),
(2, '10', 'null', 'xcvc', '787'),
(3, '10', 'null', 'mystu', '200'),
(4, '10', 'null', 'pan', '200'),
(5, '10', 'null', 'Maths Matrix', '200'),
(6, '10', 'null', 'staff', '200'),
(7, '10', 'null', 'varun', '787'),
(8, '10', 'null', 'staff', '200'),
(9, '2', '10', 'Good', '30'),
(10, '2', '10', 'Maths Matrix', '200'),
(11, 'null', '12', 'Excellent', '200'),
(12, 'null', '12', 'fefe', '222'),
(13, '3', '12', 'Excellent', '333');

-- --------------------------------------------------------

--
-- Table structure for table `faculityreg`
--

CREATE TABLE `faculityreg` (
  `fid` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `pass` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `faculityreg`
--

INSERT INTO `faculityreg` (`fid`, `name`, `email`, `phone`, `subject`, `pass`) VALUES
(10, 'mystaff', 'mystaff@gmail.com', '67556565698', 'computer', '123'),
(12, 'jstaff', 'jstaff@gmail.com', '8877666756', 'Biology', '123');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `logid` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `pass` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `uid` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`logid`, `name`, `pass`, `status`, `type`, `uid`) VALUES
(3, 'admin@gmail.com', 'admin', 'admin', '1', '0'),
(12, 'mystaff@gmail.com', '123', 'stu', '1', '10'),
(13, 'mystudent@gmail.com', '123', 'fac', '1', '2'),
(15, 'jstaff@gmail.com', '123', 'fac', '1', '12'),
(16, 'jstudent@gmail.com', '123', 'stu', '1', '3');

-- --------------------------------------------------------

--
-- Table structure for table `sch_exam`
--

CREATE TABLE `sch_exam` (
  `sid` int(11) NOT NULL,
  `que` varchar(200) NOT NULL,
  `f` varchar(200) NOT NULL,
  `s` varchar(200) NOT NULL,
  `t` varchar(255) NOT NULL,
  `ff` varchar(200) NOT NULL,
  `ans` varchar(200) NOT NULL,
  `stuid` varchar(200) NOT NULL,
  `staffid` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sch_exam`
--

INSERT INTO `sch_exam` (`sid`, `que`, `f`, `s`, `t`, `ff`, `ans`, `stuid`, `staffid`) VALUES
(34, 'hghggh', 'ffgh', 'jhhj', 'vhggh', 'jkhjk', 'C', '', ''),
(35, '  nbbvbb', 'njhjhjh', 'jhjhjh', 'kjjh', 'jn', 'A', '', ''),
(36, 'hghggh', 'ffgh', 'jhhj', 'vhggh', 'jkhjk', 'C', '', ''),
(37, '  nbbvbb', 'njhjhjh', 'jhjhjh', 'kjjh', 'jn', 'A', '', ''),
(38, 'hghggh', 'ffgh', 'jhhj', 'vhggh', 'jkhjk', 'C', '', ''),
(39, '  nbbvbb', 'njhjhjh', 'jhjhjh', 'kjjh', 'jn', 'A', '', ''),
(40, 'Blaahhh', 'Aavo', 'Ariyilla', 'Soukaryamilla', 'Thanks', 'A', '', ''),
(41, 'Again Blaah', 'Again AAvo', 'Again Ariyilla', 'Again Soukaryamilla', 'Again Thanks', 'B', '', ''),
(42, 'Again 123', 'hai', 'haaaaai', 'haaaaahaiaaia', 'nothing', 'A', '', ''),
(43, 'something', 'one', 'two', 'three', 'four', 'C', '2', ''),
(44, 'who is SQL?', 'sql', 'mysql', 'xamp', 'wamp', 'A', '2', ''),
(45, 'what is means by data?', 'java', 'css', 'mysql', 'HTML', 'A', '2', ''),
(46, '', '', '', '', '', 'A', '', ''),
(47, 'hgh 2', 'bnbvb', 'nbb', 'vbvnb', 'bvb', 'C', '2', '10'),
(48, 'fgfg 2', 'nbn', 'hn', 'nmnm', 'gghg', 'C', '2', '10'),
(49, 'What is Means of JAVA', 'Programming', 'Designing', 'Processor', 'coding', 'A', 'null', '12'),
(50, 'is Java is a Complied?', 'No', 'Yes', 'Interperted', 'JIT', 'B', 'null', '12'),
(51, 'C is Mother Language?', 'Yes', 'Earlier code', 'no', 'cpp', 'A', 'null', '12'),
(52, 'ee', 'e', 'r', 'vg', 'rt', 'A', 'null', '12'),
(53, 'dsds', 'ss', 'wqer', 'xamp', 'wamp', 'A', '3', '12'),
(54, 'ddd', 'sql', 'wqer', 'rgr', 'wamp', 'A', '3', '12');

-- --------------------------------------------------------

--
-- Table structure for table `studentattenexam`
--

CREATE TABLE `studentattenexam` (
  `ueid` int(11) NOT NULL,
  `ques` varchar(200) NOT NULL,
  `ans` varchar(200) NOT NULL,
  `studid` varchar(200) NOT NULL,
  `staff` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentattenexam`
--

INSERT INTO `studentattenexam` (`ueid`, `ques`, `ans`, `studid`, `staff`) VALUES
(17, 'something', 'D', '2', '10'),
(18, 'something', 'D', '2', '10'),
(19, 'something', 'D', '2', '10'),
(20, 'what is means by data?', 'D', '2', '10'),
(21, 'what is means by data?', 'D', '2', '10'),
(22, 'fgfg 2', 'D', '2', '10'),
(23, 'fgfg 2', 'D', '2', '10'),
(24, 'fgfg 2', 'D', '2', '10'),
(25, 'fgfg 2', 'D', '2', '10'),
(26, 'fgfg 2', 'D', '2', '10'),
(27, 'fgfg 2', 'D', '2', '10'),
(28, 'who is SQL?', 'C', '2', '10'),
(29, 'what is means by data?', 'B', '2', '10'),
(30, 'hgh 2', 'D', '2', '10'),
(31, 'hgh 2', 'D', '2', '10'),
(32, 'hgh 2', 'D', '2', '10'),
(33, 'dsds', 'D', '3', '12'),
(34, 'ddd', 'D', '3', '12');

-- --------------------------------------------------------

--
-- Table structure for table `studentreg`
--

CREATE TABLE `studentreg` (
  `sid` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `class` varchar(200) NOT NULL,
  `pass` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentreg`
--

INSERT INTO `studentreg` (`sid`, `name`, `email`, `phone`, `class`, `pass`) VALUES
(1, 'varun', 'varun@gmail.com', '6755556', '2', '123'),
(2, 'mystu', 'mystudent@gmail.com', '5454656545', '5 th', '123'),
(3, 'jstudent', 'jstudent@gmail.com', '8877666756', '11 th', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assignment`
--
ALTER TABLE `assignment`
  ADD PRIMARY KEY (`agnid`);

--
-- Indexes for table `entermark`
--
ALTER TABLE `entermark`
  ADD PRIMARY KEY (`emid`);

--
-- Indexes for table `examresult`
--
ALTER TABLE `examresult`
  ADD PRIMARY KEY (`erid`);

--
-- Indexes for table `faculityreg`
--
ALTER TABLE `faculityreg`
  ADD PRIMARY KEY (`fid`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`logid`);

--
-- Indexes for table `sch_exam`
--
ALTER TABLE `sch_exam`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `studentattenexam`
--
ALTER TABLE `studentattenexam`
  ADD PRIMARY KEY (`ueid`);

--
-- Indexes for table `studentreg`
--
ALTER TABLE `studentreg`
  ADD PRIMARY KEY (`sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assignment`
--
ALTER TABLE `assignment`
  MODIFY `agnid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `entermark`
--
ALTER TABLE `entermark`
  MODIFY `emid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `examresult`
--
ALTER TABLE `examresult`
  MODIFY `erid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `faculityreg`
--
ALTER TABLE `faculityreg`
  MODIFY `fid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `logid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `sch_exam`
--
ALTER TABLE `sch_exam`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `studentattenexam`
--
ALTER TABLE `studentattenexam`
  MODIFY `ueid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `studentreg`
--
ALTER TABLE `studentreg`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
