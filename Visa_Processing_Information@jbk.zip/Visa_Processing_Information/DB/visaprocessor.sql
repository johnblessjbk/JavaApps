/*
SQLyog Ultimate v11.33 (64 bit)
MySQL - 5.5.8-log : Database - visaprocessor
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`visaprocessor` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `visaprocessor`;

/*Table structure for table `applyvisa` */

DROP TABLE IF EXISTS `applyvisa`;

CREATE TABLE `applyvisa` (
  `vid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `passportno` varchar(100) DEFAULT NULL,
  `mstatus` varchar(100) DEFAULT NULL,
  `age` varchar(100) DEFAULT NULL,
  `qualification` varchar(100) DEFAULT NULL,
  `religion` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `mother` varchar(100) DEFAULT NULL,
  `father` varchar(100) DEFAULT NULL,
  `gurdian` varchar(100) DEFAULT NULL,
  `disablity` varchar(100) DEFAULT NULL,
  `expiry` varchar(100) DEFAULT NULL,
  `uid` varchar(100) DEFAULT NULL,
  `type` varchar(100) DEFAULT 'no',
  `visaid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`vid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `applyvisa` */

LOCK TABLES `applyvisa` WRITE;

insert  into `applyvisa`(`vid`,`name`,`email`,`phone`,`address`,`passportno`,`mstatus`,`age`,`qualification`,`religion`,`country`,`mother`,`father`,`gurdian`,`disablity`,`expiry`,`uid`,`type`,`visaid`) values (1,'Jenisha J','2022-10-13','6789768776','Kerala','78976897','signle','32@gmail.com','MCA','Chritsian','India','Santhi','johnrose@gmail.com','8885645665','No','YY/2022','1','no','2'),(3,'Ajin','2022-10-20','7686786784','Tamil NAdu','575678567876','Unmaried','22','BCA','Christian','Ityaly','MothrerMary','FatherJohn','JohnRose','No','22/2033','1','verfy','3'),(4,'Manirathianm','2022-10-13','7887568568','Kerala','7897897689','Signle','33','BCA','Muslim','America','Santhi','JohnRose','Father','NIO','22/33','2','verfy','4');

UNLOCK TABLES;

/*Table structure for table `login` */

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `pass` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `uid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `login` */

LOCK TABLES `login` WRITE;

insert  into `login`(`id`,`name`,`pass`,`status`,`type`,`uid`) values (1,'vishnu@gmail.com','123','user','1','1'),(2,'admin@gmail.com','admin','admin','1','0'),(3,'visa@gmail.com','123','visa','1','1'),(4,'Darshan@gmail.com','123','visa','1','2'),(5,'jenisha@gmail.com','123','user','1','2'),(6,'john@gmail.com','123','visa','1','3'),(7,'reshmi@gmail.com','123','visa','1','4');

UNLOCK TABLES;

/*Table structure for table `renewal` */

DROP TABLE IF EXISTS `renewal`;

CREATE TABLE `renewal` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `dob` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `passno` varchar(100) DEFAULT NULL,
  `purpose` varchar(100) DEFAULT NULL,
  `edate` varchar(100) DEFAULT NULL,
  `renew` varchar(100) DEFAULT NULL,
  `passexp` varchar(100) DEFAULT NULL,
  `descrip` varchar(100) DEFAULT NULL,
  `files` varchar(100) DEFAULT NULL,
  `uid` varchar(100) DEFAULT NULL,
  `type` varchar(100) DEFAULT 'no',
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `renewal` */

LOCK TABLES `renewal` WRITE;

insert  into `renewal`(`rid`,`name`,`dob`,`phone`,`passno`,`purpose`,`edate`,`renew`,`passexp`,`descrip`,`files`,`uid`,`type`) values (1,'bjkjh','2022-10-07','9999999999','567567','65745gfhfd','gfhfgh@bvhfg','fghfg','hfghf','qq.jfif','qq.jfif','1','yes'),(2,'JohnBlessed','2022-10-08','9998767335','868978','TO tRavel','11/22/3333@ff','11/11/22323','Visa job','ere','dataget.jpg','1','no'),(3,'dfgdfg','2022-10-08','9898977676','6766787','ghhhjh','6765','jhjhjh','hjgh','ertr','WomenSecuriety Abstract (1) (2).pdf','2','yes'),(4,'Mithin','2022-10-13','8790789789','7567457','TO Travel','33/5554','44/756','Job Visa','','PetVet.docx','2','yes');

UNLOCK TABLES;

/*Table structure for table `sendreplay` */

DROP TABLE IF EXISTS `sendreplay`;

CREATE TABLE `sendreplay` (
  `rplyid` int(11) NOT NULL AUTO_INCREMENT,
  `Renewal` varchar(100) DEFAULT NULL,
  `Departure` varchar(100) DEFAULT NULL,
  `Arrival` varchar(100) DEFAULT NULL,
  `Location` varchar(100) DEFAULT NULL,
  `uid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`rplyid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

/*Data for the table `sendreplay` */

LOCK TABLES `sendreplay` WRITE;

insert  into `sendreplay`(`rplyid`,`Renewal`,`Departure`,`Arrival`,`Location`,`uid`) values (8,'2022-10-15','2022-10-13','2022-11-06','etert','3'),(9,'2022-10-25','2022-10-29','2022-10-12','Trivantrum','4');

UNLOCK TABLES;

/*Table structure for table `userreg` */

DROP TABLE IF EXISTS `userreg`;

CREATE TABLE `userreg` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `pass` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `userreg` */

LOCK TABLES `userreg` WRITE;

insert  into `userreg`(`uid`,`name`,`email`,`phone`,`address`,`pass`) values (1,'vishnu','vishnu@gmail.com','8985685685','TamilNadu','123'),(2,'jsnisha','jenisha@gmail.com','7657567567','Kerala','123');

UNLOCK TABLES;

/*Table structure for table `verifyvisa` */

DROP TABLE IF EXISTS `verifyvisa`;

CREATE TABLE `verifyvisa` (
  `vyid` int(11) NOT NULL AUTO_INCREMENT,
  `locationfrom` varchar(100) DEFAULT NULL,
  `locateto` varchar(100) DEFAULT NULL,
  `depdate` varchar(100) DEFAULT NULL,
  `arivaldate` varchar(100) DEFAULT NULL,
  `apyid` varchar(100) DEFAULT NULL,
  `userid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`vyid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `verifyvisa` */

LOCK TABLES `verifyvisa` WRITE;

insert  into `verifyvisa`(`vyid`,`locationfrom`,`locateto`,`depdate`,`arivaldate`,`apyid`,`userid`) values (2,'Italy','chennai','2022-10-14T18:49','2022-10-14T12:01','3','1'),(3,'Chenntharai','nagercivil','2022-10-20T10:10','2022-10-15T10:09','4','2');

UNLOCK TABLES;

/*Table structure for table `visaprocessor` */

DROP TABLE IF EXISTS `visaprocessor`;

CREATE TABLE `visaprocessor` (
  `vid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `pass` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`vid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `visaprocessor` */

LOCK TABLES `visaprocessor` WRITE;

insert  into `visaprocessor`(`vid`,`name`,`email`,`phone`,`address`,`pass`) values (1,'visa','visa@gmail.com','8998978676','Kerala','123'),(2,'Darshan','Darshan@gmail.com','7867856756','Tamil NAdu kaera','123'),(3,'john','john@gmail.com','7567567567','TamilNadu','123'),(4,'reshmi','reshmi@gmail.com','6576575676','reshmi address','123');

UNLOCK TABLES;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
