/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Connection;

/**
 *
 * @author Admin
 */
class jenisha{
int no=88;
     jenisha() {
    }
    void jhello(){
        
    }
    
}
class devika extends jenisha{
int age;
   

     devika() {
         super();
         System.out.println("hai");
    }
      devika(int age) {
          this();
         this.age=age;
    }
    void dhello(){
        System.out.println(this.age);  
                System.out.println(this.no);  

    }
      void mm(){
          this.dhello();
          super.jhello();
        System.out.println(this.age);  
                System.out.println(super.no);  

    }
}
public class hello {

  public static void main(String[] args) {
  devika d=new devika(22);
  d.mm();
    }
    
}
